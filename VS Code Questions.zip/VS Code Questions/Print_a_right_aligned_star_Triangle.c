//Print a triangle aligned to the right using leading spaces and asterisks.
#include <stdio.h>

int main() {
    int n = 10;

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n - i; j++) {
            printf(" ");
        }

        for (int j = 1; j <= i; j++) {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
